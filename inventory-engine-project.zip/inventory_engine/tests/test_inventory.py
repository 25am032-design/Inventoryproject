from datetime import date

import pytest

from inventory_engine import (
    DuplicateItemError, ElectronicItem, InsufficientStockError, InvalidItemError,
    Inventory, ItemNotFoundError, PerishableItem, StandardItem,
)
from inventory_engine.exceptions import InventoryError

TODAY = date(2026, 11, 19)


@pytest.fixture
def inv():
    i = Inventory()
    i.add_item(StandardItem("pen", "Blue Pen", 1.5, 100))
    i.add_item(ElectronicItem("lap", "Laptop", 800, 3))
    i.add_item(PerishableItem("mlk", "Milk", 2, 10, "2026-12-31"))
    i.add_item(PerishableItem("old", "Old Cheese", 5, 4, "2026-01-01"))
    return i


def test_len_contains_iter_sorted(inv):
    assert len(inv) == 4
    assert "PEN" in inv and " pen " in inv and "zzz" not in inv and 5 not in inv
    assert [i.sku for i in inv] == ["LAP", "MLK", "OLD", "PEN"]


def test_duplicate_and_invalid_add(inv):
    with pytest.raises(DuplicateItemError) as exc:
        inv.add_item(StandardItem("PEN", "Other", 1, 1))
    assert exc.value.sku == "PEN"
    with pytest.raises(InvalidItemError):
        inv.add_item("not an item")


def test_get_and_not_found(inv):
    assert inv.get("pen").name == "Blue Pen"
    with pytest.raises(ItemNotFoundError) as exc:
        inv.get("nope")
    assert "nope" in str(exc.value)
    with pytest.raises(ItemNotFoundError):
        inv.get(None)


def test_remove_item(inv):
    removed = inv.remove_item("pen")
    assert removed.sku == "PEN" and "pen" not in inv
    with pytest.raises(ItemNotFoundError):
        inv.remove_item("pen")


def test_restock_and_sell(inv):
    inv.restock("pen", 10)
    inv.sell("pen", 60)
    assert inv.get("pen").quantity == 50
    with pytest.raises(InsufficientStockError):
        inv.sell("pen", 1000)
    with pytest.raises(ItemNotFoundError):
        inv.sell("ghost", 1)


def test_total_value_uses_polymorphism(inv):
    # pen 150 + laptop 2400 + milk 20 + expired cheese 0
    assert inv.total_value(TODAY) == 2570.0


def test_queries(inv):
    assert [i.sku for i in inv.low_stock(4)] == ["LAP", "OLD"]
    assert [i.sku for i in inv.expired(TODAY)] == ["OLD"]
    assert [i.sku for i in inv.search("MILK")] == ["MLK"]
    assert [i.sku for i in inv.search("la")] == ["LAP"]


def test_report(inv):
    text = inv.report(TODAY)
    assert "TOTAL VALUE: 2570.00" in text
    assert "Laptop" in text


def test_all_errors_share_base(inv):
    for exc_type in (DuplicateItemError, ItemNotFoundError, InsufficientStockError, InvalidItemError):
        assert issubclass(exc_type, InventoryError)
