from datetime import date

import pytest

from inventory_engine import (
    ElectronicItem, InsufficientStockError, InvalidItemError, Item,
    PerishableItem, StandardItem,
)

TODAY = date(2026, 11, 19)


def test_item_is_abstract():
    with pytest.raises(TypeError):
        Item("A1", "x", 1.0, 1)


def test_standard_item_basics_and_normalisation():
    i = StandardItem("  ab1 ", " Widget ", 2.5, 4)
    assert (i.sku, i.name, i.unit_price, i.quantity) == ("AB1", "Widget", 2.5, 4)
    assert i.total_value() == 10.0
    assert "Widget" in i.describe() and "AB1" in repr(i)


@pytest.mark.parametrize("kwargs", [
    dict(sku="", name="n", unit_price=1, quantity=1),
    dict(sku=5, name="n", unit_price=1, quantity=1),
    dict(sku="a", name=" ", unit_price=1, quantity=1),
    dict(sku="a", name="n", unit_price=-1, quantity=1),
    dict(sku="a", name="n", unit_price="1", quantity=1),
    dict(sku="a", name="n", unit_price=True, quantity=1),
    dict(sku="a", name="n", unit_price=1, quantity=-1),
    dict(sku="a", name="n", unit_price=1, quantity=1.5),
])
def test_invalid_construction(kwargs):
    with pytest.raises(InvalidItemError):
        StandardItem(**kwargs)


def test_invalid_item_error_is_value_error():
    with pytest.raises(ValueError):
        StandardItem("a", "n", -1, 1)


def test_stock_operations():
    i = StandardItem("a", "n", 1, 5)
    i.add_stock(3)
    i.remove_stock(8)
    assert i.quantity == 0


def test_remove_too_much_raises_with_details():
    i = StandardItem("a", "n", 1, 2)
    with pytest.raises(InsufficientStockError) as exc:
        i.remove_stock(5)
    assert (exc.value.requested, exc.value.available) == (5, 2)


@pytest.mark.parametrize("bad", [0, -1, 1.5, True, "2"])
def test_bad_stock_amounts(bad):
    i = StandardItem("a", "n", 1, 2)
    with pytest.raises(InvalidItemError):
        i.add_stock(bad)
    with pytest.raises(InvalidItemError):
        i.remove_stock(bad)


def test_perishable_valuation_polymorphism():
    fresh = PerishableItem("m", "Milk", 2.0, 10, "2026-12-31")
    soon = PerishableItem("y", "Yogurt", 2.0, 10, "2026-11-22")
    old = PerishableItem("c", "Cheese", 2.0, 10, "2026-11-01")
    assert fresh.total_value(TODAY) == 20.0
    assert soon.total_value(TODAY) == 10.0   # 50% near-expiry discount
    assert old.total_value(TODAY) == 0.0
    assert old.is_expired(TODAY) and not fresh.is_expired(TODAY)
    assert "expires 2026-12-31" in fresh.describe()
    assert isinstance(fresh.expiry_date, date)


def test_perishable_defaults_to_real_today():
    assert PerishableItem("m", "Milk", 1, 1, date(2000, 1, 1)).is_expired()


def test_perishable_requires_valid_expiry():
    with pytest.raises(InvalidItemError):
        PerishableItem("m", "Milk", 1, 1)
    with pytest.raises(InvalidItemError):
        PerishableItem("m", "Milk", 1, 1, "not-a-date")


def test_electronic_item():
    e = ElectronicItem("t", "Laptop", 500, 2, warranty_months=24)
    assert e.total_value() == 1000.0
    assert e.warranty_months == 24
    assert "24-month warranty" in e.describe()
    with pytest.raises(InvalidItemError):
        ElectronicItem("t", "Laptop", 500, 2, warranty_months=-1)


def test_subclasses_are_items():
    items = [StandardItem("a", "A", 1, 1), ElectronicItem("b", "B", 1, 1),
             PerishableItem("c", "C", 1, 1, "2099-01-01")]
    assert all(isinstance(i, Item) for i in items)
    assert [i.total_value(TODAY) for i in items] == [1.0, 1.0, 1.0]


@pytest.mark.parametrize("item", [
    StandardItem("a", "A", 1.25, 3),
    ElectronicItem("b", "B", 99.99, 2, 6),
    PerishableItem("c", "C", 3, 4, "2030-05-06"),
])
def test_round_trip_dict(item):
    clone = Item.from_dict(item.to_dict())
    assert type(clone) is type(item)
    assert clone == item


def test_from_dict_errors():
    with pytest.raises(InvalidItemError):
        Item.from_dict("nope")
    with pytest.raises(InvalidItemError):
        Item.from_dict({"type": "alien", "sku": "a"})
    with pytest.raises(InvalidItemError):
        Item.from_dict({"type": "standard", "sku": "a"})


def test_from_dict_defaults_to_standard():
    i = Item.from_dict({"sku": "a", "name": "n", "unit_price": 1, "quantity": 1})
    assert isinstance(i, StandardItem)


def test_equality_and_unhashable():
    assert StandardItem("a", "n", 1, 1) != "x"
    with pytest.raises(TypeError):
        hash(StandardItem("a", "n", 1, 1))
