import pytest

from inventory_engine import (
    ElectronicItem, Inventory, PerishableItem, StandardItem, StorageError, storage,
)


@pytest.fixture
def inv():
    i = Inventory()
    i.add_item(StandardItem("pen", "Blue, Pen", 1.5, 100))   # comma tests CSV quoting
    i.add_item(ElectronicItem("lap", "Laptop", 800, 3, 24))
    i.add_item(PerishableItem("mlk", "Milk", 2, 10, "2026-12-31"))
    return i


def snapshot(i):
    return [x.to_dict() for x in i]


def test_json_round_trip(tmp_path, inv):
    p = tmp_path / "inv.json"
    storage.save_json(inv, p)
    assert snapshot(storage.load_json(p)) == snapshot(inv)


def test_csv_round_trip(tmp_path, inv):
    p = tmp_path / "inv.csv"
    storage.save_csv(inv, p)
    assert snapshot(storage.load_csv(p)) == snapshot(inv)


def test_json_missing_file(tmp_path):
    with pytest.raises(StorageError):
        storage.load_json(tmp_path / "nope.json")


def test_json_malformed(tmp_path):
    p = tmp_path / "bad.json"
    p.write_text("{ oops")
    with pytest.raises(StorageError, match="malformed JSON"):
        storage.load_json(p)


@pytest.mark.parametrize("text", ["[]", '{"items": "x"}', '{"other": []}'])
def test_json_wrong_shape(tmp_path, text):
    p = tmp_path / "bad.json"
    p.write_text(text)
    with pytest.raises(StorageError, match="expected an object"):
        storage.load_json(p)


def test_json_bad_record_reports_position(tmp_path):
    p = tmp_path / "bad.json"
    p.write_text('{"items": [{"sku":"a","name":"n","unit_price":1,"quantity":1}, '
                 '{"sku":"b","name":"n","unit_price":-5,"quantity":1}]}')
    with pytest.raises(StorageError, match="record 2"):
        storage.load_json(p)


def test_json_duplicate_sku_in_file(tmp_path):
    rec = '{"sku":"a","name":"n","unit_price":1,"quantity":1}'
    p = tmp_path / "dup.json"
    p.write_text('{"items": [%s, %s]}' % (rec, rec))
    with pytest.raises(Exception, match="already exists"):
        storage.load_json(p)


def test_save_to_bad_path(tmp_path, inv):
    bad = tmp_path / "no_such_dir" / "f"
    with pytest.raises(StorageError):
        storage.save_json(inv, bad)
    with pytest.raises(StorageError):
        storage.save_csv(inv, bad)


def test_csv_missing_file(tmp_path):
    with pytest.raises(StorageError):
        storage.load_csv(tmp_path / "nope.csv")


def test_csv_empty_file(tmp_path):
    p = tmp_path / "e.csv"
    p.write_text("")
    with pytest.raises(StorageError, match="empty"):
        storage.load_csv(p)


def test_csv_missing_columns(tmp_path):
    p = tmp_path / "c.csv"
    p.write_text("sku,name\nA,B\n")
    with pytest.raises(StorageError, match="missing required column"):
        storage.load_csv(p)


def test_csv_bad_number(tmp_path):
    p = tmp_path / "c.csv"
    p.write_text("type,sku,name,unit_price,quantity\nstandard,A,B,abc,1\n")
    with pytest.raises(StorageError, match="line 2"):
        storage.load_csv(p)


def test_csv_missing_value(tmp_path):
    p = tmp_path / "c.csv"
    p.write_text("type,sku,name,unit_price,quantity\nstandard,A,B,,1\n")
    with pytest.raises(StorageError, match="missing column value"):
        storage.load_csv(p)


def test_csv_bad_record_content(tmp_path):
    p = tmp_path / "c.csv"
    p.write_text("type,sku,name,unit_price,quantity\nalien,A,B,1,1\n")
    with pytest.raises(StorageError, match="unknown item type"):
        storage.load_csv(p)


def test_csv_not_utf8(tmp_path):
    p = tmp_path / "c.csv"
    p.write_bytes(b"\xff\xfe\x00bad")
    with pytest.raises(StorageError):
        storage.load_csv(p)
