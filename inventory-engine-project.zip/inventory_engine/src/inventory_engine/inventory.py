"""The Inventory container."""

from __future__ import annotations

from datetime import date
from typing import Dict, Iterator, List, Optional

from inventory_engine.exceptions import DuplicateItemError, InvalidItemError, ItemNotFoundError
from inventory_engine.models import Item, PerishableItem


class Inventory:
    """A collection of Items keyed by SKU."""

    def __init__(self) -> None:
        self._items: Dict[str, Item] = {}

    # ----- container protocol -----
    def __len__(self) -> int:
        return len(self._items)

    def __contains__(self, sku: object) -> bool:
        return isinstance(sku, str) and sku.strip().upper() in self._items

    def __iter__(self) -> Iterator[Item]:
        for sku in sorted(self._items):
            yield self._items[sku]

    # ----- CRUD -----
    def add_item(self, item: Item) -> None:
        if not isinstance(item, Item):
            raise InvalidItemError("only Item instances can be added")
        if item.sku in self._items:
            raise DuplicateItemError(item.sku)
        self._items[item.sku] = item

    def get(self, sku: str) -> Item:
        key = sku.strip().upper() if isinstance(sku, str) else sku
        try:
            return self._items[key]
        except KeyError:
            raise ItemNotFoundError(str(sku)) from None

    def remove_item(self, sku: str) -> Item:
        item = self.get(sku)
        del self._items[item.sku]
        return item

    # ----- stock operations -----
    def restock(self, sku: str, amount: int) -> None:
        self.get(sku).add_stock(amount)

    def sell(self, sku: str, amount: int) -> None:
        self.get(sku).remove_stock(amount)

    # ----- queries -----
    def total_value(self, as_of: Optional[date] = None) -> float:
        """Sum of each item's polymorphic total_value()."""
        return round(sum(item.total_value(as_of) for item in self), 2)

    def low_stock(self, threshold: int = 5) -> List[Item]:
        return [i for i in self if i.quantity <= threshold]

    def expired(self, as_of: Optional[date] = None) -> List[PerishableItem]:
        return [i for i in self if isinstance(i, PerishableItem) and i.is_expired(as_of)]

    def search(self, text: str) -> List[Item]:
        needle = text.strip().lower()
        return [i for i in self if needle in i.name.lower() or needle in i.sku.lower()]

    def report(self, as_of: Optional[date] = None) -> str:
        lines = [i.describe() + f" -> value {i.total_value(as_of):.2f}" for i in self]
        lines.append(f"TOTAL VALUE: {self.total_value(as_of):.2f}")
        return "\n".join(lines)
