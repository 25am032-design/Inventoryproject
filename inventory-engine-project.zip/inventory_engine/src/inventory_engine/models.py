"""Item class hierarchy.

Demonstrates:
  * Encapsulation  - state is held in private attributes behind validated properties.
  * Inheritance    - StandardItem, PerishableItem and ElectronicItem extend Item.
  * Polymorphism   - each subclass overrides total_value() / describe() / to_dict().
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from datetime import date
from typing import Any, Dict, Optional, Type

from inventory_engine.exceptions import InsufficientStockError, InvalidItemError

EXPIRY_DISCOUNT_DAYS = 7
EXPIRY_DISCOUNT_RATE = 0.5


def _parse_date(value: Any, field: str) -> date:
    if isinstance(value, date):
        return value
    try:
        return date.fromisoformat(str(value))
    except ValueError:
        raise InvalidItemError(f"{field} must be an ISO date (YYYY-MM-DD), got {value!r}") from None


class Item(ABC):
    """Abstract base class for everything stored in an inventory."""

    type_name = "item"

    def __init__(self, sku: str, name: str, unit_price: float, quantity: int = 0):
        self.sku = sku
        self.name = name
        self.unit_price = unit_price
        self._quantity = 0
        self.quantity = quantity

    # ----- validated properties (encapsulation) -----
    @property
    def sku(self) -> str:
        return self._sku

    @sku.setter
    def sku(self, value: str) -> None:
        if not isinstance(value, str) or not value.strip():
            raise InvalidItemError("sku must be a non-empty string")
        self._sku = value.strip().upper()

    @property
    def name(self) -> str:
        return self._name

    @name.setter
    def name(self, value: str) -> None:
        if not isinstance(value, str) or not value.strip():
            raise InvalidItemError("name must be a non-empty string")
        self._name = value.strip()

    @property
    def unit_price(self) -> float:
        return self._unit_price

    @unit_price.setter
    def unit_price(self, value: float) -> None:
        if isinstance(value, bool) or not isinstance(value, (int, float)) or value < 0:
            raise InvalidItemError(f"unit_price must be a non-negative number, got {value!r}")
        self._unit_price = round(float(value), 2)

    @property
    def quantity(self) -> int:
        return self._quantity

    @quantity.setter
    def quantity(self, value: int) -> None:
        if isinstance(value, bool) or not isinstance(value, int) or value < 0:
            raise InvalidItemError(f"quantity must be a non-negative integer, got {value!r}")
        self._quantity = value

    # ----- stock operations -----
    def add_stock(self, amount: int) -> None:
        if isinstance(amount, bool) or not isinstance(amount, int) or amount <= 0:
            raise InvalidItemError(f"amount must be a positive integer, got {amount!r}")
        self._quantity += amount

    def remove_stock(self, amount: int) -> None:
        if isinstance(amount, bool) or not isinstance(amount, int) or amount <= 0:
            raise InvalidItemError(f"amount must be a positive integer, got {amount!r}")
        if amount > self._quantity:
            raise InsufficientStockError(self._sku, amount, self._quantity)
        self._quantity -= amount

    # ----- polymorphic behaviour -----
    @abstractmethod
    def total_value(self, as_of: Optional[date] = None) -> float:
        """Value of the stock on hand."""

    def describe(self) -> str:
        return f"[{self.sku}] {self.name} x{self.quantity} @ {self.unit_price:.2f}"

    def to_dict(self) -> Dict[str, Any]:
        return {
            "type": self.type_name,
            "sku": self.sku,
            "name": self.name,
            "unit_price": self.unit_price,
            "quantity": self.quantity,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Item":
        """Build the correct subclass from a dict (factory)."""
        if not isinstance(data, dict):
            raise InvalidItemError("item record must be an object")
        type_name = data.get("type", "standard")
        subclass = ITEM_TYPES.get(type_name)
        if subclass is None:
            raise InvalidItemError(f"unknown item type {type_name!r}")
        try:
            return subclass._build(data)
        except KeyError as exc:
            raise InvalidItemError(f"missing field {exc.args[0]!r} in item record") from None

    @classmethod
    def _build(cls, data: Dict[str, Any]) -> "Item":
        return cls(data["sku"], data["name"], data["unit_price"], data["quantity"])

    def __repr__(self) -> str:
        return f"{type(self).__name__}(sku={self.sku!r}, name={self.name!r}, quantity={self.quantity})"

    def __eq__(self, other: object) -> bool:
        return isinstance(other, Item) and self.to_dict() == other.to_dict()

    __hash__ = None  # mutable, compared by value


class StandardItem(Item):
    """Ordinary stock: value is price x quantity."""

    type_name = "standard"

    def total_value(self, as_of: Optional[date] = None) -> float:
        return round(self.unit_price * self.quantity, 2)


class PerishableItem(Item):
    """Stock that expires. Expired stock is worthless; near-expiry stock is discounted."""

    type_name = "perishable"

    def __init__(self, sku, name, unit_price, quantity=0, expiry_date=None):
        super().__init__(sku, name, unit_price, quantity)
        if expiry_date is None:
            raise InvalidItemError("perishable items require an expiry_date")
        self._expiry_date = _parse_date(expiry_date, "expiry_date")

    @property
    def expiry_date(self) -> date:
        return self._expiry_date

    def is_expired(self, as_of: Optional[date] = None) -> bool:
        return (as_of or date.today()) > self._expiry_date

    def total_value(self, as_of: Optional[date] = None) -> float:
        today = as_of or date.today()
        if self.is_expired(today):
            return 0.0
        base = self.unit_price * self.quantity
        if (self._expiry_date - today).days <= EXPIRY_DISCOUNT_DAYS:
            base *= 1 - EXPIRY_DISCOUNT_RATE
        return round(base, 2)

    def describe(self) -> str:
        return f"{super().describe()} (expires {self._expiry_date.isoformat()})"

    def to_dict(self) -> Dict[str, Any]:
        data = super().to_dict()
        data["expiry_date"] = self._expiry_date.isoformat()
        return data

    @classmethod
    def _build(cls, data):
        return cls(data["sku"], data["name"], data["unit_price"], data["quantity"], data["expiry_date"])


class ElectronicItem(Item):
    """Electronics carry a warranty; value is price x quantity."""

    type_name = "electronic"

    def __init__(self, sku, name, unit_price, quantity=0, warranty_months=12):
        super().__init__(sku, name, unit_price, quantity)
        if isinstance(warranty_months, bool) or not isinstance(warranty_months, int) or warranty_months < 0:
            raise InvalidItemError(f"warranty_months must be a non-negative integer, got {warranty_months!r}")
        self._warranty_months = warranty_months

    @property
    def warranty_months(self) -> int:
        return self._warranty_months

    def total_value(self, as_of: Optional[date] = None) -> float:
        return round(self.unit_price * self.quantity, 2)

    def describe(self) -> str:
        return f"{super().describe()} ({self._warranty_months}-month warranty)"

    def to_dict(self) -> Dict[str, Any]:
        data = super().to_dict()
        data["warranty_months"] = self._warranty_months
        return data

    @classmethod
    def _build(cls, data):
        return cls(data["sku"], data["name"], data["unit_price"], data["quantity"],
                   data.get("warranty_months", 12))


ITEM_TYPES: Dict[str, Type[Item]] = {
    c.type_name: c for c in (StandardItem, PerishableItem, ElectronicItem)
}
