"""Inventory Engine - OOP inventory management with robust error handling."""

from inventory_engine.exceptions import (
    DuplicateItemError,
    InsufficientStockError,
    InvalidItemError,
    InventoryError,
    ItemNotFoundError,
    StorageError,
)
from inventory_engine.inventory import Inventory
from inventory_engine.models import ElectronicItem, Item, PerishableItem, StandardItem
from inventory_engine import storage

__version__ = "1.0.0"

__all__ = [
    "Inventory", "Item", "StandardItem", "PerishableItem", "ElectronicItem",
    "InventoryError", "InvalidItemError", "DuplicateItemError",
    "ItemNotFoundError", "InsufficientStockError", "StorageError", "storage",
]
