"""Custom exception hierarchy.

All engine errors derive from InventoryError so callers can catch one type.
"""


class InventoryError(Exception):
    """Base class for all inventory engine errors."""


class InvalidItemError(InventoryError, ValueError):
    """Raised when item data (sku, name, price, quantity, ...) is invalid."""


class DuplicateItemError(InventoryError):
    """Raised when adding an item whose SKU already exists."""

    def __init__(self, sku: str):
        super().__init__(f"item with SKU '{sku}' already exists")
        self.sku = sku


class ItemNotFoundError(InventoryError, KeyError):
    """Raised when a SKU is not present in the inventory."""

    def __init__(self, sku: str):
        super().__init__(f"no item with SKU '{sku}'")
        self.sku = sku

    def __str__(self) -> str:  # KeyError would otherwise repr() the message
        return self.args[0]


class InsufficientStockError(InventoryError):
    """Raised when removing more stock than is available."""

    def __init__(self, sku: str, requested: int, available: int):
        super().__init__(
            f"insufficient stock for '{sku}': requested {requested}, available {available}"
        )
        self.sku, self.requested, self.available = sku, requested, available


class StorageError(InventoryError):
    """Raised when reading or writing JSON/CSV persistence fails."""
