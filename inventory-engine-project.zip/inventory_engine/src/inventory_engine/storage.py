"""JSON and CSV persistence.

All I/O and parsing problems are converted to StorageError (or InvalidItemError
for bad record contents) so callers handle one family of exceptions.
"""

from __future__ import annotations

import csv
import json
from pathlib import Path
from typing import Any, Dict, List, Union

from inventory_engine.exceptions import InvalidItemError, StorageError
from inventory_engine.inventory import Inventory
from inventory_engine.models import Item

PathLike = Union[str, Path]

CSV_FIELDS = ["type", "sku", "name", "unit_price", "quantity", "expiry_date", "warranty_months"]


def _inventory_from_records(records: List[Dict[str, Any]], source: str) -> Inventory:
    inv = Inventory()
    for n, record in enumerate(records, start=1):
        try:
            inv.add_item(Item.from_dict(record))
        except InvalidItemError as exc:
            raise StorageError(f"{source}: record {n}: {exc}") from exc
    return inv


# ---------------- JSON ----------------

def save_json(inventory: Inventory, path: PathLike) -> None:
    payload = {"items": [item.to_dict() for item in inventory]}
    try:
        Path(path).write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    except OSError as exc:
        raise StorageError(f"cannot write {path}: {exc.strerror or exc}") from exc


def load_json(path: PathLike) -> Inventory:
    try:
        text = Path(path).read_text(encoding="utf-8")
    except OSError as exc:
        raise StorageError(f"cannot read {path}: {exc.strerror or exc}") from exc
    try:
        data = json.loads(text)
    except json.JSONDecodeError as exc:
        raise StorageError(f"malformed JSON in {path}: {exc.msg} (line {exc.lineno})") from exc
    if not isinstance(data, dict) or not isinstance(data.get("items"), list):
        raise StorageError(f"{path}: expected an object with an 'items' list")
    return _inventory_from_records(data["items"], str(path))


# ---------------- CSV ----------------

def save_csv(inventory: Inventory, path: PathLike) -> None:
    try:
        with open(path, "w", newline="", encoding="utf-8") as fh:
            writer = csv.DictWriter(fh, fieldnames=CSV_FIELDS, restval="")
            writer.writeheader()
            for item in inventory:
                writer.writerow(item.to_dict())
    except OSError as exc:
        raise StorageError(f"cannot write {path}: {exc.strerror or exc}") from exc


def _clean_csv_row(row: Dict[str, str], source: str, line: int) -> Dict[str, Any]:
    record: Dict[str, Any] = {k: v for k, v in row.items() if k and v not in (None, "")}
    try:
        record["unit_price"] = float(record["unit_price"])
        record["quantity"] = int(record["quantity"])
        if "warranty_months" in record:
            record["warranty_months"] = int(record["warranty_months"])
    except KeyError as exc:
        raise StorageError(f"{source}: line {line}: missing column value {exc.args[0]!r}") from None
    except ValueError as exc:
        raise StorageError(f"{source}: line {line}: invalid number ({exc})") from None
    return record


def load_csv(path: PathLike) -> Inventory:
    try:
        with open(path, newline="", encoding="utf-8") as fh:
            reader = csv.DictReader(fh)
            if reader.fieldnames is None:
                raise StorageError(f"{path}: file is empty")
            missing = {"sku", "name", "unit_price", "quantity"} - set(reader.fieldnames)
            if missing:
                raise StorageError(f"{path}: missing required column(s): {', '.join(sorted(missing))}")
            records = [_clean_csv_row(row, str(path), n) for n, row in enumerate(reader, start=2)]
    except (OSError, UnicodeDecodeError) as exc:
        raise StorageError(f"cannot read {path}: {getattr(exc, 'strerror', None) or exc}") from exc
    except csv.Error as exc:
        raise StorageError(f"malformed CSV in {path}: {exc}") from exc
    return _inventory_from_records(records, str(path))
