"""Demo: build an inventory, trigger errors gracefully, persist to JSON and CSV."""
from datetime import date
from pathlib import Path

from inventory_engine import (
    ElectronicItem, Inventory, InventoryError, PerishableItem, StandardItem, storage,
)

OUT = Path(__file__).parent / "data"
OUT.mkdir(exist_ok=True)
AS_OF = date(2026, 11, 19)

inv = Inventory()
inv.add_item(StandardItem("PEN-01", "Blue Pen", 1.50, 120))
inv.add_item(ElectronicItem("LAP-01", "Laptop", 799.99, 3, warranty_months=24))
inv.add_item(PerishableItem("MLK-01", "Milk 1L", 1.20, 40, "2026-11-22"))
inv.add_item(PerishableItem("CHS-01", "Old Cheese", 5.00, 6, "2026-10-01"))

print(inv.report(AS_OF))

print("\n-- graceful error handling --")
for label, action in [
    ("sell too much", lambda: inv.sell("LAP-01", 10)),
    ("unknown SKU", lambda: inv.get("XXX")),
    ("duplicate SKU", lambda: inv.add_item(StandardItem("pen-01", "Dup", 1, 1))),
    ("negative price", lambda: StandardItem("BAD", "Bad", -5, 1)),
]:
    try:
        action()
    except InventoryError as exc:
        print(f"{label}: {type(exc).__name__}: {exc}")

storage.save_json(inv, OUT / "inventory.json")
storage.save_csv(inv, OUT / "inventory.csv")
reloaded = storage.load_csv(OUT / "inventory.csv")
print(f"\nSaved JSON + CSV, reloaded {len(reloaded)} items; "
      f"total value {reloaded.total_value(AS_OF):.2f}")
